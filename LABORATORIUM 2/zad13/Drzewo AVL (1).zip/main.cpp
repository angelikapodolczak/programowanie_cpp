#include <iostream>
#include "drzewo.h"
#include "element.h"
using namespace std;

int main()
{
    int rozmiar; //liczba elementow
    int elem;
    Drzewo *drzewo = new Drzewo;
    
    cin>>rozmiar; 
    
    for(int i=0; i<rozmiar; i++)
    {
       cin>>elem;
       drzewo->dodaj1(elem);
    }
   
    drzewo->wyswietl(drzewo->podaj_korzen());
    
    delete drzewo;
    
    return 0;
}