#include <iostream>
#include "drzewo.h"
#include "element.h"
using namespace std;

/////////////////////
//KONSTRUKTORY
Element :: Element ()
{
    lewy = nullptr;
    prawy = nullptr;
}

Element :: Element (int a)
{
    lewy = nullptr;
    prawy = nullptr;
    wartosc=a;
}


/////////////////////////
//WARTOSC
int Element :: podaj_wartosc() 
{
    return wartosc;
}


/////////////////////////////
//ZWRACA KOLEJNE ELEMENTY
Element *Element :: zwroc_lewy()
{
    return lewy;
}

Element *Element :: zwroc_prawy()
{
    return prawy;
}


//////////////////////////////////
//USTAWIA ELEMENTY
void Element :: ustaw_lewy(Element *nowy,int a)
{
    delete lewy;
    lewy=nowy;
    lewy->wartosc = a;
}

void Element :: ustaw_lewy(Element *nowy)
{
    this->lewy=lewy;
    lewy=nowy;
}

void Element :: ustaw_prawy(Element *nowy)
{
    this->prawy=prawy;
    prawy=nowy;
}

void Element :: ustaw_prawy(Element *nowy,int a)
{
    delete prawy;
    prawy=nowy;
    prawy->wartosc = a;
}


///////////////////////////////////
//OBROTY I ROWNOWAZENIE
Element* Element :: w_prawo()
{
    Element *wezelA = this;
    Element *wezelB = wezelA->zwroc_lewy();
    
    wezelA->ustaw_lewy(wezelB->zwroc_prawy());
    wezelB->ustaw_prawy(wezelA);
    
    int Ar = wezelA->rownowaga, Br = wezelB->rownowaga;
    if(Br<=0)
    {
        if(Br>Ar) wezelB->rownowaga = Br + 1;
        else wezelB->rownowaga = Ar + 2;
        wezelA->rownowaga= Ar - Br + 1;
    }
    else 
    {
        if(Ar<=-1) wezelB->rownowaga = Br + 1;
        else wezelB->rownowaga = Ar + Br + 2;
        wezelA->rownowaga = Ar + 1;
    }
    return wezelB;
}


Element*  Element ::  w_lewo()
{
    Element *wezelA = this;
    Element *wezelB = wezelA->zwroc_prawy();
    
    wezelA->ustaw_prawy(wezelB->zwroc_lewy());
    wezelB->ustaw_lewy(wezelA);
    
    int Ar = wezelA->rownowaga, Br = wezelB->rownowaga;
    if(Br<=0)
    {
        if(Ar>=0) wezelB->rownowaga = Br - 1;
        else wezelB->rownowaga = Ar + Br - 2;
        wezelA->rownowaga = Ar - 1;
    }
    else 
    {
        if(Ar<=Br) wezelB->rownowaga = Ar -2;
        else wezelB->rownowaga = Br - 1;
        wezelA->rownowaga = Ar -Br - 1;
    }
    return wezelB;
}


Element* Element :: balans()
{
    if(rownowaga<0)
    {
        if(lewy->rownowaga<=0)
            return w_prawo();
        else
        {
            ustaw_lewy(lewy->w_lewo());
            return w_prawo();
        }
    }
    else
    {
        if(prawy->rownowaga>=0)
            return w_lewo();
        else
        {
            ustaw_prawy(prawy->w_prawo());
            return w_lewo();
        }
    }
}


Element* Element :: dodaj(int w)
{
    if(w<wartosc)
    {
        if(lewy)
        {
            int sta_row = lewy->rownowaga;
            ustaw_lewy(lewy->dodaj(w));
            if((lewy->rownowaga!=sta_row) and lewy->rownowaga) rownowaga--;
        }
        else
        {
            ustaw_lewy(new Element(w));
            rownowaga--;
        }
    }
    else
    {
        if(prawy)
        {
            int sta_row = prawy->rownowaga;
            ustaw_prawy(prawy->dodaj(w));
            if((prawy->rownowaga!=sta_row) and prawy->rownowaga) rownowaga++;
        }
        else
        {
            ustaw_prawy(new Element(w));
            rownowaga++;
        }
    }
    if((rownowaga<-1) or (rownowaga>1))
        return balans();
    return this;
    
}


///////////////////////////
//DESTRUKTOR
Element :: ~Element()
{
    delete lewy;
    delete prawy;
}