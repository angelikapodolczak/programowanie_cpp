#include <iostream>
#include "drzewo.h"
#include "element.h"
using namespace std;


Drzewo :: Drzewo()
{
    korzen = nullptr;
}


void Drzewo :: dodaj1(int wartosc) 
{
    if(korzen) korzen=korzen->dodaj(wartosc);
    else korzen = new Element(wartosc);
}


Element* Drzewo::podaj_korzen()
{
    return korzen;
}


void Drzewo :: wyswietl(Element *el)
{
    if(el)
    {
        cout<<el->podaj_wartosc()<<" ";
        wyswietl(el->zwroc_lewy());
        wyswietl(el->zwroc_prawy());
    }
}



Drzewo :: ~Drzewo()
{
    delete korzen;    
}