#ifndef FIGURA_H
#define FIGURA_H
using namespace std;

class Figura
{
    protected:
        double pole;

    public:
        Figura(double p);
        double zwroc();
};

#endif