#ifndef TROJKAT_H
#define TROJKAT_H
using namespace std;
#include "figura.h"

class Trojkat :public Figura
{
    public:
        Trojkat(double x, double h);
        ~Trojkat();
};

#endif